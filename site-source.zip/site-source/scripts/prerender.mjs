import { readFile, writeFile } from 'node:fs/promises';
import { render } from '../.ssr-build/prerender.js';
const path = new URL('../dist/index.html', import.meta.url);
let html = await readFile(path,'utf8');
if(!html.includes('<div id="root"></div>')) throw new Error('Static rendering target missing');
html=html.replace('<div id="root"></div>',()=>'<div id="root">'+render()+'</div>');
await writeFile(path,html);
console.log('Static HTML rendered for search and first paint.');
