import { cp, writeFile, readFile } from 'node:fs/promises';
const root=new URL('../',import.meta.url);
const target=new URL('../',root);
if((await readFile(new URL('CNAME',target),'utf8')).trim()!=='thulaim.com') throw new Error('Unexpected domain; stop and review.');
await cp(new URL('dist/',root),target,{recursive:true});
await writeFile(new URL('.nojekyll',target),'');
console.log('GitHub Pages files updated locally; commit them to publish.');
