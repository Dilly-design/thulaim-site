
## October 2026 photo direction

- Hero: `photo-table.webp`, existing Thulaim table photograph. Food details shown at larger scale; originals are not retouched.
- `photo-signature.webp`: Thulaim Drive IMG_5660.HEIC (`1p_Q0q_BkUWkLdrhttaYAkDiLmG3yHhir`), converted to WebP.
- `photo-gathering.webp`: Thulaim Drive IMG_5652.HEIC (`10crQ_vxLDmDFDitD4JlsvUVWLcq1wkq3`), converted to WebP.
- Dessert and service images reused from the original Thulaim website.
- No stock or generated photographs are presented as Thulaim events.

## Expanded gallery — 6 October 2026

- `photo-feast.webp`: Thulaim Drive `IMG_1488.jpg` (`1F7bn1Y8jSbv39L9e4bD6VEDrVmRRc008`). Resized and converted to WebP; no creative retouching.
- `photo-warm-dessert.webp`: Thulaim Drive `IMG_1457.jpg` (`1UmRe-Bf57tdarDTNkQDOvwS2ChrVgp4H`). Resized and converted to WebP; no creative retouching.
- `photo-evening.webp`: Thulaim Drive `IMG_1433.jpg` (`1CFsXzX33m1K6W1vzoBzSMFXeiqO5GjbK`). Resized and converted to WebP; no creative retouching.
- `photo-fruit.webp`: Thulaim Drive `IMG_1462.jpg` (`1IE6rXN5mC-avf-d1nWuC6KLT6Dgr3qdQ`). Resized and converted to WebP; no creative retouching.
- `photo-meat.webp`: Thulaim Drive `نسخة من IMG_4108.jpg` (`1imzCXx_uUBhyiiX1HteA2Xv2K8nTVm4h`). Resized and converted to WebP; no creative retouching.
- `photo-bites.webp`: Thulaim Drive `نسخة من IMG_4118.jpg` (`1qwqx0oAeDomgBnBWMT_782jVZH3l8VJR`). Resized and converted to WebP; no creative retouching.
- `photo-rolls.webp`: Thulaim Drive `نسخة من IMG_4122.jpg` (`1pH_mpqXApqz4sj6SwhuzJPOqLgRlugvJ`). Resized and converted to WebP; no creative retouching.
