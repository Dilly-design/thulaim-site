# Thulaim landing page source

The repository root contains the static GitHub Pages output. This directory contains the editable React/Vite source. The existing custom domain is retained in the root CNAME file.

## Update

1. Run `npm ci` inside `site-source`.
2. Edit `src/App.jsx` and `src/style.css`.
3. Run `npm run pages`. It builds static HTML and assets, then updates the repository root.
4. Review the diff and commit the output plus source. Publish through the repository's existing GitHub Pages publishing branch.

No server, paid hosting, new DNS record, or GitHub Actions workflow is required by this build. Confirm the existing Pages branch/folder in GitHub Settings before merging.

Main CTA opens WhatsApp 966579444843 with a draft. Opening WhatsApp is not a submitted lead. The menu builder prepares an estimate and a draft message; the customer still sends it. Existing unit pricing remains 180 SAR per guest, optional setup 50 SAR per guest, VAT 15%.

Photo provenance is in ASSETS.md. Existing original JSX, assets, fonts, and the social image were preserved in the repository. The old blog comprised promotional cards that opened booking, with no separate article routes; those cards are replaced by occasion choices.
