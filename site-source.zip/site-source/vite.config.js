import { defineConfig } from 'vite';
export default defineConfig({base:'./',server:{host:'0.0.0.0',port:Number(process.env.PORT)||3000,strictPort:true,allowedHosts:['terminal.local']}});
