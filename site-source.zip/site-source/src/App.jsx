import React, { useEffect, useRef, useState } from 'react';
import { BookingModal } from './booking.jsx';
import './style.css';
import './editorial.css';

const WA = 'https://wa.me/966579444843';
const A = './assets/';
const quoteLink = occasion => WA+'?text='+encodeURIComponent(`السلام عليكم، أرغب في عرض ضيافة من ثليم.\nنوع المناسبة: ${occasion||''}\nعدد الضيوف: \nالتاريخ: \nالموقع في الرياض: `);
const eventTypes = [['تميمة','aqiqah'],['عقيقة','aqiqah'],['زواج','wedding'],['ملكة','milkah'],['شبكة','shabka'],['لمّة عائلية','family']];
const questions = [
  ['كيف أطلب ضيافة ثُليم؟','تواصل معنا مباشرة عبر واتساب لطلب عرض، أو اختر «اختر قائمتك» وحدّد المناسبة وعدد الضيوف والأصناف. راجع التفاصيل والتقدير ثم أرسل طلبك للفريق.'],
  ['هل أقدر أختار الأصناف بنفسي؟','نعم. في نموذج الطلب قائمة مقترحة بحسب عدد ضيوفك، ويمكنك تعديل الأصناف من المقبلات والسلطات إلى الأطباق الرئيسية والحلويات.'],
  ['كيف أعرف تكلفة الضيافة؟','يظهر لك تقدير في نموذج الطلب بحسب عدد الضيوف وخيار التجهيز. يراجع الفريق تفاصيل المناسبة معك لتأكيد العرض النهائي. للمناسبات الأكبر من ٦٠ ضيفًا نعدّ عرضًا مخصصًا.'],
  ['وش يشمل التجهيز والتقديم؟','ننسّق معك احتياجات المكان: طاولات الضيافة، ترتيب التقديم، وطاقم الخدمة. يحدد العرض المتفق عليه التفاصيل التي تشملها مناسبتك.'],
  ['متى أتواصل معكم؟','شاركنا التاريخ المتوقع بمجرد تحديده. يراجع الفريق توفر الموعد ومتطلبات التجهيز معك قبل تأكيد الحجز.'],
];

function Brand({dark=false}) { return <span className="brand"><img src={A+(dark?'logo-dark.png':'logo-light.png')} alt="ثُليم" width="132" height="132" /></span> }
function WhatsAppButton({children='اطلب عرضًا عبر واتساب',light=false,className=''}) {return <a href={quoteLink()} target="_blank" rel="noreferrer" className={`button whatsapp-button ${light?'button-light':''} ${className}`}><span>{children}</span><span className="wa-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M20.5 11.6a8.5 8.5 0 0 1-12.4 7.5L3 20.5l1.4-5A8.5 8.5 0 1 1 20.5 11.6Z"/><path d="M8.3 7.8c.4-.3.9 1.2 1.2 1.7.2.4-.6.8-.5 1.2.4 1.1 1.4 2.2 2.5 2.8.5.3 1-.6 1.5-.6.4.1 2 1 1.9 1.4-.3 1.3-1.5 1.5-2.6 1.2-3.2-.9-5.9-3.8-5.6-6.1.1-.7.9-1.4 1.6-1.6Z"/></svg></span></a>}
function Label({number,children}) {return <div className="section-label" data-reveal><span>{children}</span><span className="section-number">{number}</span></div>}

function App(){
  const [book,setBook]=useState(false), [prefill,setPrefill]=useState(null);
  const [menu,setMenu]=useState(false), [scrolled,setScrolled]=useState(false);
  const [faq,setFaq]=useState(null);
  const [motionPaused,setMotionPaused]=useState(false), [heroVisible,setHeroVisible]=useState(true);
  const heroRef=useRef(null), galleryRef=useRef(null);
  const openBooking=(value)=>{setMenu(false);setPrefill(value?{occasion:value}:null);setBook(true)};

  useEffect(()=>{
    const media=window.matchMedia('(prefers-reduced-motion: reduce)');
    let frame=0;
    const update=()=>{
      frame=0;setScrolled(window.scrollY>60);
      const reduced=media.matches||motionPaused;
      document.documentElement.classList.toggle('motion-paused',reduced);
      if(heroRef.current){
        const rect=heroRef.current.getBoundingClientRect();
        setHeroVisible(rect.bottom>90);
        const distance=Math.max(heroRef.current.offsetHeight-window.innerHeight,1);
        const progress=reduced?0:Math.min(1,Math.max(0,-rect.top/distance));
        heroRef.current.style.setProperty('--p',progress.toFixed(4));
      }

    };
    const tick=()=>{if(!frame)frame=requestAnimationFrame(update)};
    window.addEventListener('scroll',tick,{passive:true});window.addEventListener('resize',tick);media.addEventListener('change',tick);update();
    const obs=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');obs.unobserve(e.target)}})},{threshold:.12});
    document.querySelectorAll('[data-reveal]').forEach(el=>obs.observe(el));
    return()=>{window.removeEventListener('scroll',tick);window.removeEventListener('resize',tick);media.removeEventListener('change',tick);cancelAnimationFrame(frame);obs.disconnect()};
  },[motionPaused]);

  useEffect(()=>{
    if(!menu)return;
    const handler=e=>{if(e.key==='Escape')setMenu(false)};
    document.addEventListener('keydown',handler);return()=>document.removeEventListener('keydown',handler);
  },[menu]);

  const galleryMove=(direction)=>{const el=galleryRef.current;if(el)el.scrollBy({left:direction*el.clientWidth*.75,behavior:motionPaused||window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'})};
  return <>
    <a className="skip-link" href="#main">انتقل إلى المحتوى</a>
    <header className={`site-header ${scrolled?'is-scrolled':''}`}>
      <a href="#main" className="brand-link" aria-label="ثليم، الرئيسية"><Brand/></a>
      <nav className="desktop-nav" aria-label="القائمة الرئيسية"><a href="#occasions">ضيافتنا</a><a href="#story">حكايتنا</a><a href="#gallery">من مناسباتنا</a></nav>
      <div className="header-actions"><button className="header-booking" onClick={()=>openBooking()}>اختر قائمتك</button><button className={`menu-toggle ${menu?'is-open':''}`} aria-expanded={menu} aria-controls="mobile-menu" aria-label={menu?'إغلاق القائمة':'فتح القائمة'} onClick={()=>setMenu(!menu)}><span/><span/></button></div>
    </header>
    {menu&&<nav className="mobile-menu" id="mobile-menu" aria-label="روابط الموقع">{[['occasions','ضيافتنا'],['story','حكايتنا'],['gallery','من مناسباتنا'],['faq','يسألوننا']].map(([id,text],i)=><a key={id} href={'#'+id} onClick={()=>setMenu(false)}><span>{text}</span><small>0{i+1}</small></a>)}<button className="menu-booking" onClick={()=>openBooking()}>اختر قائمتك</button><a className="menu-contact" href={WA} target="_blank" rel="noreferrer">تواصل عبر واتساب</a></nav>}
    <main id="main">
      <section className="hero" ref={heroRef} aria-labelledby="hero-title">
        <div className="hero-stage">
          <div className="hero-photo"><img src={A+'photo-table.webp'} alt="مقبلات وسلطات ثليم على مائدة إحدى المناسبات" fetchpriority="high" width="2000" height="2667"/></div>
          <div className="hero-shade"/>
          <div className="hero-brand-art" aria-hidden="true"><img src={A+'logo-light.png'} alt="" width="640" height="640"/></div>
          <div className="hero-topline"><span>بيت ضيافة سعودي</span><span lang="en" dir="ltr">THULAIM — RIYADH</span></div>
          <div className="hero-copy">
            <h1 id="hero-title"><span>يطيب</span><span>اللقاء.</span></h1>
            <p className="hero-description">ضيافة تُشرف، وكرم يُروى.</p>
            <div className="hero-actions"><WhatsAppButton light>اطلب عبر واتساب</WhatsAppButton></div>
          </div>
          <div className="hero-foot"><a href="#gallery" className="scroll-prompt"><span className="scroll-line" aria-hidden="true"/>تفضّل، اكتشف ثُليم</a><span>ضيافة مناسبات خاصة · الرياض</span></div>
        </div>
      </section>

      <section className="gallery-section" id="gallery">
        <div className="section-heading section-shell" data-reveal><div><h2>من موائد ثُليم.</h2></div><div className="gallery-nav"><button onClick={()=>galleryMove(1)} aria-label="الصور السابقة">السابق</button><span>/</span><button onClick={()=>galleryMove(-1)} aria-label="الصور التالية">التالي</button></div></div>
        <div className="gallery-track" ref={galleryRef} tabIndex={0} aria-label="صور من ضيافة ثليم، اسحب أو استخدم زري السابق والتالي">{[
          ['photo-bites.webp','أول الحفاوة','مقبّلات وسلطات'],['photo-evening.webp','حين نجتمع','من تجهيزاتنا'],['photo-fruit.webp','ألوان اللقاء','فاكهة وحلوى'],['photo-meat.webp','كرم الضيافة','من أطباقنا الرئيسية'],['photo-rolls.webp','تفاصيل المذاق','من أطباقنا'],['photo-warm-dessert.webp','ختامها حلو','حلويات دافئة'],['photo-feast.webp','على المائدة','أطباقنا الرئيسية'],['photo-desserts.webp','على ذائقتك','تقديم فردي'],['photo-gathering.webp','تحت السماء','من مناسباتنا']
        ].map(([photo,title,sub],i)=><figure className="gallery-card" key={photo} data-reveal="photo"><div><img src={A+photo} alt={title+' — '+sub} loading="lazy" width="1012" height="1800"/></div><figcaption><span><strong>{title}</strong><small>{sub}</small></span><span className="gallery-number">0{i+1}</span></figcaption></figure>)}</div>
        <p className="swipe-hint">اسحب الصور لاكتشاف المزيد</p>
      </section>

      <section className="occasion-invitation section-shell" id="occasions" aria-labelledby="occasions-title">
        <div className="occasion-invitation-heading">
          <h2 id="occasions-title">على ذوق مناسبتك.</h2>
          <p>اختر مناسبتك، ونبدأ بالقائمة.</p>
        </div>
        <div className="occasion-choices" aria-label="اختر نوع مناسبتك">
          {eventTypes.map(([label,value])=><button type="button" key={label} onClick={()=>openBooking(value)}>{label}</button>)}
        </div>
      </section>

      <section className="story" id="story">
        <figure className="story-photo" data-reveal><img src={A+'photo-signature.webp'} alt="بطاقة ثليم مع تفاصيل أدوات الضيافة على المائدة" loading="lazy" width="2000" height="3556"/><figcaption>العناية، في كل تفصيل.</figcaption></figure>
        <div className="story-copy" data-reveal><Label number="٠٣">حكاية الاسم</Label><h2>من كرم الرياض،<br/>تبدأ حكايتنا.</h2><span className="story-rule"/><p>من ذاكرة «مضيف ثُليم» في الرياض، نستمد روح الحفاوة. ونقدّمها اليوم في موائد نعتني بكل تفاصيلها، من أول ترحيب حتى آخر لقاء.</p><span className="story-signature">ثُليم</span><small>ضيافة تُشرف، وكرم يُروى.</small></div>
      </section>

      <section className="faq section-shell" id="faq"><div data-reveal><Label number="٠٤">قبل اللقاء</Label><h2>يسألوننا.</h2><a className="text-link" href={WA} target="_blank" rel="noreferrer">لديك سؤال آخر؟ تواصل معنا</a></div><div className="faq-list">{questions.map(([q,a],i)=><div className={`faq-item ${faq===i?'expanded':''}`} key={q}><h3><button aria-expanded={faq===i} aria-controls={'answer-'+i} onClick={()=>setFaq(faq===i?null:i)}><span>{q}</span><span aria-hidden="true">{faq===i?'−':'+'}</span></button></h3><div className="faq-answer" id={'answer-'+i} hidden={faq!==i}><p>{a}</p></div></div>)}</div></section>

      <section className="closing section-shell"><Label number="أهلًا وسهلًا">موعدنا، مناسبتك القادمة</Label><div className="closing-content" data-reveal><h2>حيّ ضيوفك.</h2><div><p>واجعل للّقاء حكاية تُروى.</p><WhatsAppButton light/><button onClick={()=>openBooking()} className="closing-wa">أو اختر قائمتك وشاهد التقدير</button></div></div></section>
    </main>
    <footer className="site-footer section-shell"><div className="footer-top"><a href="#main" aria-label="العودة إلى أعلى الصفحة"><Brand dark/></a><p>بيت ضيافة سعودي.<br/>الرياض، المملكة العربية السعودية.</p><div className="social-links"><a href="https://www.instagram.com/thulaimcatering/" target="_blank" rel="noreferrer">إنستغرام</a><a href="https://www.tiktok.com/@thulaimcatering/" target="_blank" rel="noreferrer">تيك توك</a><a href={WA} target="_blank" rel="noreferrer">واتساب</a></div></div><div className="footer-bottom"><span>© {new Intl.NumberFormat('ar-SA',{useGrouping:false}).format(new Date().getFullYear())} ثُليم</span><button className="motion-control" aria-pressed={motionPaused} onClick={()=>setMotionPaused(!motionPaused)}>{motionPaused?'تفعيل الحركة':'تقليل الحركة'}</button><span lang="en" dir="ltr">SAUDI HOSPITALITY, THOUGHTFULLY SERVED.</span></div></footer>
    {!heroVisible&&!book&&!menu&&<div className="mobile-book"><span>موعدنا، مناسبتك.</span><WhatsAppButton>اطلب عرضًا · واتساب</WhatsAppButton></div>}
    <BookingModal open={book} onClose={()=>setBook(false)} prefill={prefill}/>
  </>;
}

export default App;
